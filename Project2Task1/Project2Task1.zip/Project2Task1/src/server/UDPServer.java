/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.net.*;
import java.io.*;
import java.util.Arrays;
import java.util.TreeMap;
/**
 *it is a UDPServer class run as a server for UDP protocol
 * @author jinge
 */
public class UDPServer {
    public static void main(String[] args){
        DatagramSocket aSocket = null;//initialize the datagramSocket for receiving and sending information
        TreeMap<String, String> locationMap= new TreeMap<>();
        //initialize the treemap to save city-location pairs and give it some values
        locationMap.put("Pittsburgh,PA", "40.4406, -79.9958");
        locationMap.put("New York,NY", "40.7142, -74.0064");
        locationMap.put("Los Angeles,CA","34.0522, -118.2427");
        locationMap.put("Houston,TX", "29.7630, -95.3630");
		try{
	    	aSocket = new DatagramSocket(6789);
					// create socket at agreed port
			byte[] buffer = null;
                        //initialize an array of byte to receive 
 			while(true){
                            //make the server socket start all the time to hear from the client
                                buffer= new byte[1000];
 				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                                //initialize a datagrampacket, and start it
  				aSocket.receive(request);                                
                                int length= 0;
                                byte[] read= request.getData();
                                while(read[length]!=0)//get the real length of array of byte
                                    length++;
                                byte[] newArr= new byte[length];//save all the useful byte into the newArr
                                System.arraycopy(read, 0, newArr, 0, length);//copy to newArr
                                String receive= new String(newArr); //convert the byte array to string                               
                                String output= locationMap.get(receive);//search from the treemap and get the value
                                int backLength=0; //initialize the length of the string to send back                        
                                if(output!=null)//if found, we can get the length of the value and form a new byte array
                                    backLength= output.length();
                                byte[] sendBack= new byte[backLength];
                                if(output!=null){
                                    for(int i=0;i<backLength;i++){
                                        sendBack[i]= (byte) output.charAt(i);
                                    }
                                    //do some output according to the write up
                                    System.out.println("Handling request for "+receive);
                                } else {
                                    //if not found, print out and return an array with the length of 0.
                                    System.out.println("Was unable to handle a request for "+receive);
                                }
                                //initialize the datagrampacket to send back
    			        DatagramPacket reply = 
                                    new DatagramPacket(sendBack, backLength, request.getAddress(), request.getPort());
    			        aSocket.send(reply);
                                //send it back the client address and port
    		}
		}catch (SocketException e){System.out.println("Socket: " + e.getMessage());
		}catch (IOException e) {System.out.println("IO: " + e.getMessage());
		}finally {if(aSocket != null) aSocket.close();}
    }
}
