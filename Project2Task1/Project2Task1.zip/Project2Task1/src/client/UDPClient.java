/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.net.*;
import java.io.*;
import java.util.TreeMap;
/**
 *this method is a UDPClient class to run as a client
 * @author jinge
 */
public class UDPClient {
    public static void main(String[] args){
                
		DatagramSocket aSocket = null;
                //initialize the datagramSocket for receiving and sending information
		try {
			aSocket = new DatagramSocket();// create socket 
                        System.out.println("Enter city name and we will find its coordinates");
                        //we can read from input through a befferedReader object
                        BufferedReader content= new BufferedReader(new InputStreamReader(System.in));
                        String strContent= content.readLine();
                        //get the input to be a string and form a byte array 
			byte [] m = strContent.getBytes();                        
			InetAddress aHost = InetAddress.getByName("127.0.0.1");
                        //initialize the inet address
			int serverPort = 6789; //initialize the server port number                       
			DatagramPacket request = new DatagramPacket(m,  strContent.length(), aHost, serverPort);
			//send the information to the server using a datagramPacket 
                        aSocket.send(request);			                        
			byte[] buffer = new byte[1000];  
                        //initialize an array of byte to receive the data sent back from the server
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
                        //use the datagramPacket object to receive it
			aSocket.receive(reply);
                        int length= 0;
                        byte[] read= reply.getData();
                        while(read[length]!=0)
                            length++;//get the real length of the array
                        if(length==0)//if nothing found, print out it
                            System.out.println("Could not resolve '"+strContent+"'");
                        byte[] newArr= new byte[length];//initialize a new array to save the location data
                        System.arraycopy(read, 0, newArr, 0, length);//copy the array
                        if(length!=0)
			    System.out.println( new String(newArr));//print it out	
		}catch (SocketException e){System.out.println("Socket: " + e.getMessage());
		}catch (IOException e){System.out.println("IO: " + e.getMessage());
		}finally {if(aSocket != null) aSocket.close();}
    }
}
