/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.net.*;
import java.io.*;
import tea.TEA;
/**
 *it is a TCP Client for spy using TEA encryption
 * @author jinge
 */
public class TCPSpyUsingTEAandPasswords {
    public static void main(String[] args){
        
		Socket s = null;//initialize the socket
                
		try{
			int serverPort = 7896;//initialize the port
			s = new Socket("localhost", serverPort);    
                        //initialize the input and output stream
			DataInputStream in = new DataInputStream( s.getInputStream());
			DataOutputStream out =new DataOutputStream( s.getOutputStream());
                        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
                        //read from the system.in for spy to enter
                        System.out.println("Enter symmetric key for TEA (taking first sixteen bytes): ");
                        String key= br.readLine();//read one line
                        TEA tea= new TEA(key.getBytes());//initialize the TEA object using the public key
                        //enter the user-id, encrypt and write to the output stream
                        System.out.print("Enter your ID: ");
                        String id= br.readLine();      
                        byte[] teaByte= tea.encrypt(id.getBytes());
                        out.write(teaByte);
                        //enter the password, encrypt and write to the output stream
                        System.out.print("Enter your password: ");
                        String pWord= br.readLine();
                        teaByte= tea.encrypt(pWord.getBytes());
                        out.write(teaByte);
                        //enter the location, encrypt and write to the output stream
                        System.out.print("Enter your location: ");
                        String location= br.readLine();
                        teaByte= tea.encrypt(location.getBytes());
                        out.write(teaByte);                        
                        //create an array of byte and receive the information form server
                        byte[] dataArr= new byte[1000];
                        int length= in.read(dataArr);//read and get the length
                        if(length<0)//if the client can not read,then the length is smaller than 0 and throw an exception
                            throw new SocketException("socket is closed.");
                        byte[] newArr= new byte[length];//create a new array and get the useful information
                        System.arraycopy(dataArr, 0, newArr, 0, length);
			String data = new String(newArr);	    // read a line of data from the stream
			System.out.println("Received: "+ data) ;//receive the data and output it 
		}catch (UnknownHostException e){System.out.println("Socket:"+e.getMessage());
		}catch (EOFException e){                   
                    System.out.println("EOF:"+e.getMessage());
		}catch (IOException e){System.out.println("readline:"+e.getMessage());
		}finally {if(s!=null) try {s.close();}catch (IOException e){System.out.println("close:"+e.getMessage());}}
    }
}
