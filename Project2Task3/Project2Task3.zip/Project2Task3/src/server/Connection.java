/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static server.TCPSpyCommanderUsingTEAandPasswords.idMap;
import static server.TCPSpyCommanderUsingTEAandPasswords.num;
import static server.TCPSpyCommanderUsingTEAandPasswords.publicKey;
import static server.TCPSpyCommanderUsingTEAandPasswords.strArr;
import sun.misc.BASE64Encoder;
import tea.TEA;

/**
 *connection class extends thread. Each time create a new object will create a new thread
 * @author jinge
 */
public class Connection extends Thread {
	DataInputStream in;//input and output stream
	DataOutputStream out;
	Socket clientSocket;
        //constructor
	public Connection (Socket aClientSocket) {
		try {
			clientSocket = aClientSocket;
			in = new DataInputStream( clientSocket.getInputStream());
			out =new DataOutputStream( clientSocket.getOutputStream());
			this.start();//call the run function
		} catch(IOException e) {System.out.println("Connection:"+e.getMessage());}
	}
	public void run(){
		try {// an echo server     
                    TEA tea= new TEA(publicKey.getBytes());//initialize a new TEA object
		    byte[] oldArr= new byte[1000];
                    int length= in.read(oldArr);                    
                    byte[] newArr= new byte[length];//read from the client and get the length
                    System.arraycopy(oldArr, 0, newArr, 0, length);//copy to the new array
                    String id = new String(tea.decrypt(newArr)); //encrypt the user-id                
                    
                    oldArr= new byte[1000];//initialize the byte array to receive data
                    length= in.read(oldArr);//read from the client and get the length
                    newArr= new byte[length];
                    System.arraycopy(oldArr, 0, newArr, 0, length);//copy to the new array
                    newArr= tea.decrypt(newArr);//encrypt the password  
                    String passWd= new String(newArr);
                    MessageDigest md= MessageDigest.getInstance("MD5");//encode the password to be MD5 base value
                    byte[] mdArr= md.digest(newArr);
                    BASE64Encoder be= new BASE64Encoder();
                    passWd= be.encode(mdArr);
                    
                    
                    oldArr= new byte[1000];//initialize the byte array to receive data
                    length= in.read(oldArr);//read from the client and get the length
                    newArr= new byte[length];
                    System.arraycopy(oldArr, 0, newArr, 0, length);//copy to the new array
                    newArr= tea.decrypt(newArr);//encrypt the location value
                    String location= new String(newArr);
                    
                    boolean flagKey= true;//chect if all the values are ASCII, if not, proves illegal key
                    for(int i=0;i<newArr.length;i++){
                        if(newArr[i]<32 || newArr[i]>=127){
                            flagKey= false;
                            break;
                        }
                            
                    }
                    boolean flagPass= true;
                    String realPass= idMap.get(id);//if user-id not found or password uncorrect, flag is false
                    if(realPass==null || !realPass.equals(passWd))
                        flagPass= false;
                    


                    if(flagKey==false){//illegal key, just close the socket
                            System.out.println("Got visit "+(++num)+" illegal symmetric key used.");
                            clientSocket.close();
                            
                        } else if(flagPass==false){//wrong user-id or password, just return this string to tell client
                            System.out.println("Got visit "+(++num)+" from "+id+".Illegal password attempt.");
                            out.write("Not a valid user-id or password.".getBytes());
                            
                        } else {//both are correct
                            System.out.println("Got visit "+(++num)+" from "+id);
                            out.write("Thank you. Your location was securely transmitted to Intelligence Headquarters".getBytes());
                            PrintWriter out= new PrintWriter("SecretAgents.kml");//write the location the kml file
                            if(id.equals("jamesb")){//check whose location it is
                                strArr[3]= location;
                            }else if(id.equals("joem")){
                                strArr[5]= location;
                            } else{
                                strArr[7]= location;
                            }
                            for(int i=0;i<strArr.length;i++){
                                out.print(strArr[i]);
                            }
                            out.close();
                        
                        }
                    
                    
		}catch (EOFException e){System.out.println("EOF:"+e.getMessage());
		} catch(IOException e) {System.out.println("readline:"+e.getMessage());
		} catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
            } finally{ try {clientSocket.close();}catch (IOException e){/*close failed*/}}
		

	}
        
}
