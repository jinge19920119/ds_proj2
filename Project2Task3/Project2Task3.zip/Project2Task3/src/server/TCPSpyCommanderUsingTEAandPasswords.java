/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.net.*;
import java.io.*;
import java.util.*;
import tea.TEA;
/**
 * it is a TCP server class with all the values' initialization
 * @author jinge
 */
public class TCPSpyCommanderUsingTEAandPasswords {
    static String publicKey=null;//state as static to use it in other classes
    static TreeMap<String, String> idMap= new TreeMap<>();//treeMap object to save user-id and password
    static int num=0;//count the number of visits
    static String[] strArr= new String[9];//strArr is used to save all the string that should be written to the file
    public static void main (String args[]) {
        idMap.put("joem", "j/MkifkvM0FmlL6P3C1MIg==");//id and password for 'joe'(MD5 base value)
        idMap.put("jamesb", "tMw0TSWi7+VArb8meOIwTA==");//id and password for 'james'
        idMap.put("mikem", "GBJue9P4Sz8+TfCU3vW33g==");//for 'mike'
        strArr[0]= "<?xml version=\"1.0\" encoding=\"UTF-8\" ?> \n" +
"<kml xmlns=\"http://earth.google.com/kml/2.2\" \n" +
"><Document>\n" +
"<Style id=\"style1\"> \n" +
"<IconStyle> \n" +
"<Icon> \n" +
"<href>http://maps.gstatic.com/intl/en_ALL/mapfiles/ms/micons/blue-dot.png</href> \n" +
"</Icon> </IconStyle> </Style> <Placemark> \n" +
"<name>seanb</name> <description>Spy Commander</description> <styleUrl>#style1</styleUrl> <Point> \n" +
"<coordinates>";
        strArr[1]= "-79.945289,40.44431,0.00000";
        strArr[2]= "</coordinates> </Point> \n" +
"</Placemark> <Placemark> \n" +
"<name>jamesb</name> <description>Spy</description> <styleUrl>#style1</styleUrl> <Point> \n" +
"<coordinates>";
        strArr[3]= "-79.940450,40.437394,0.0000";//joe's location
        strArr[4]= "</coordinates> </Point> \n" +
"</Placemark> \n" +
"<Placemark> <name>joem</name> <description>Spy</description> <styleUrl>#style1</styleUrl> <Point> \n" +
"<coordinates>";
        strArr[5]= "-79.945389,40.444216,0.00000";//james' location
        strArr[6]= "</coordinates> </Point> \n" +
"</Placemark> \n" +
"<Placemark> <name>mikem</name> <description>Spy</description> <styleUrl>#style1</styleUrl> <Point> \n" +
"<coordinates>";
        strArr[7]= "-79.948460,40.444501,0.00000";//mike's location
        strArr[8]= "</coordinates> </Point> \n" +
"</Placemark> \n" +
"</Document> </kml>";
		try{                    			
                    int serverPort = 7896; // the server port
	            ServerSocket listenSocket = new ServerSocket(serverPort);  //open the socket for listening  
                    System.out.println("Enter symmetric key for TEA (taking first sixteen bytes): ");
                    BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
                    publicKey= br.readLine();//read from the user's input to get the public key
                    br.close();//close the socket
                    System.out.println("Waiting for spies to visit...");
       		    while(true) {
                        //accept for listening and create a connection
			Socket clientSocket = listenSocket.accept();
			Connection c = new Connection(clientSocket);
                                
			}
		} catch(IOException e) {System.out.println("Listen socket:"+e.getMessage());}
	}
    
    
    
        
}

