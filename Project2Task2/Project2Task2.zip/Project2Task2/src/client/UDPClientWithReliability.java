/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;

/**
 *it is a UDPClient class that has high reliability
 * @author jinge
 */
public class UDPClientWithReliability {
    public static void main(String[] args){
        System.out.println("Enter city name and we will find its coordinates");
        String strContent= "";
        try{
            //we can read from input through a befferedReader object
            BufferedReader content= new BufferedReader(new InputStreamReader(System.in));
            strContent= content.readLine();
        }catch(IOException e){
            
        }        
        String result= getLocation(strContent);//call the function of getLocation
        if(result.equals("")){//if return empty, putput something
            System.out.println("Could not resolve '"+strContent+"'");
        }else {
            System.out.println(result);
        }
    }
    /*
    getLocation function can get one city's location in its longitude and latitude.
    //precondition: city has a name in the form "city,state abbreviation"
    //postcondition: Longitude and latitude coordinates are returned or an empty string is returned if the city
            //       is not in the table
    */
    public static String getLocation(String city){
        //precondition: city has a name in the form "city,state abbreviation"
        //postcondition: Longitude and latitude coordinates are returned or an empty string is returned if the city
                //       is not in the table
        String result="";
        DatagramSocket aSocket = null;
                //initialize the datagramSocket for receiving and sending information
		try {
			aSocket = new DatagramSocket();// create socket                                                 
                        String strContent= city;
                        //get the input to be a string and form a byte array 
			byte [] m = strContent.getBytes();                        
			InetAddress aHost = InetAddress.getByName("127.0.0.1");
                        //initialize the inet address
			int serverPort = 6789; //initialize the server port number                       
			DatagramPacket request = new DatagramPacket(m,  strContent.length(), aHost, serverPort);
			//send the information to the server using a datagramPacket 
                        aSocket.setSoTimeout(1000);                        
                        aSocket.send(request);	                        
			byte[] buffer = new byte[1000];  
                        //initialize an array of byte to receive the data sent back from the server
			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
                        //use the datagramPacket object to receive it
                        while(reply.getLength()!=0){//check if it is empty
                            System.out.println("in the while loop");
                            try{
                                aSocket.receive(reply);//receive data with socket
                                break;
                            }catch(SocketTimeoutException s){//if time expiration, throw an exception
                                System.out.println("time out and send again!");
                                aSocket.send(request);//use socket to send information
                                aSocket.setSoTimeout(1000);//set the time limit again
                            }
                        }
                        int length= 0;
                        byte[] read= reply.getData();//convert to array of byte
                        while(read[length]!=0)
                            length++;//get the real length of the array
                        
                        if(length==0)//if nothing found, print out it
                            result= "";
                        else {
                            byte[] newArr= new byte[length];//initialize a new array to save the location data
                            System.arraycopy(read, 0, newArr, 0, length);//copy the array
                            result= new String(newArr);//put the array of byte into the result
                        }                          			    	
		}catch (SocketException e){System.out.println("Socket: " + e.getMessage());
		}catch (IOException e){System.out.println("IO: " + e.getMessage());
		}finally {
                    if(aSocket != null) 
                        aSocket.close();                   
                }
                return result;
        
    }
}
